# Verifica si dos enteros con el mismo valor son el mismo objeto

numero1 = 10
numero2 = 10

if numero1 is numero2:
    print("Los números son el mismo objeto en memoria")
else:
    print("Los números son objetos diferentes en memoria")