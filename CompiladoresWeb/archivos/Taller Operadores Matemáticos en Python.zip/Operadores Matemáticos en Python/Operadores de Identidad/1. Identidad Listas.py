# Verifica si dos listas son el mismo objeto en memoria

lista1 = [1, 2, 3]
lista2 = [1, 2, 3]

if lista1 is lista2:
    print("Las listas son el mismo objeto en memoria")
else:
    print("Las listas son objetos diferentes en memoria")