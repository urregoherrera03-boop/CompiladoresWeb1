# Compara la identidad de dos diccionarios

diccionario1 = {
    "nombre": "Juan",
    "edad": 20
}

diccionario2 = {
    "nombre": "Juan",
    "edad": 20
}

if diccionario1 is diccionario2:
    print("Los diccionarios son el mismo objeto")
else:
    print("Los diccionarios son objetos diferentes en memoria")