# Verifica si dos cadenas son el mismo objeto

texto1 = "Python"
texto2 = "Python"

if texto1 is texto2:
    print("Las cadenas son el mismo objeto en memoria")
else:
    print("Las cadenas son objetos diferentes en memoria")