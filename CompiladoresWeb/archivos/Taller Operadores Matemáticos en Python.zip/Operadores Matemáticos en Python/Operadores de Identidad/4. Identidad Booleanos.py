# Verifica si dos valores booleanos son el mismo objeto

booleano1 = True
booleano2 = True

if booleano1 is booleano2:
    print("Los valores booleanos son el mismo objeto")
else:
    print("Los valores booleanos son objetos diferentes")