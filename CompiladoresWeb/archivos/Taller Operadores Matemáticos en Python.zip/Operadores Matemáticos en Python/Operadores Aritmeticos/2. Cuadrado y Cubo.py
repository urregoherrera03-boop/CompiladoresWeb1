# Programa para calcular el cuadrado y cubo de un número

numero = float(input("Ingrese un número: "))

cuadrado = numero ** 2
cubo = numero ** 3

print("El cuadrado es:", cuadrado)
print("El cubo es:", cubo)