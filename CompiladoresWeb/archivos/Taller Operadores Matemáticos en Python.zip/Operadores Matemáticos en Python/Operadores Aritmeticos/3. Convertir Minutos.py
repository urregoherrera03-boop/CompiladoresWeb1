# Programa que convierte minutos en horas y minutos restantes

minutos = int(input("Ingrese la cantidad de minutos: "))

horas = minutos // 60
minutos_restantes = minutos % 60

print("Horas:", horas)
print("Minutos restantes:", minutos_restantes)