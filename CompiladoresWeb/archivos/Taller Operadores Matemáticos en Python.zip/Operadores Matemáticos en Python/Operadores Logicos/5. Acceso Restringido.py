# Comprueba acceso mediante rol y contraseña

rol = input("Ingrese su rol: ")
contraseña = input("Ingrese su contraseña: ")

if rol == "admin" and contraseña == "1234":
    print("Acceso permitido")
else:
    print("Acceso denegado")