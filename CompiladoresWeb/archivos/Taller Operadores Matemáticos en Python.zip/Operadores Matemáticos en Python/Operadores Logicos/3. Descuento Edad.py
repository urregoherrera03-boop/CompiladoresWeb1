# Determina si una persona es apta para un descuento

edad = int(input("Ingrese la edad de la persona: "))

if edad < 12 or edad > 60:
    print("La persona tiene derecho al descuento")
else:
    print("La persona no tiene derecho al descuento")