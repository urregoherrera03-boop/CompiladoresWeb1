# Verifica si un número no es negativo usando not

numero = float(input("Ingrese un número: "))

if not numero < 0:
    print("El número no es negativo")
else:
    print("El número es negativo")