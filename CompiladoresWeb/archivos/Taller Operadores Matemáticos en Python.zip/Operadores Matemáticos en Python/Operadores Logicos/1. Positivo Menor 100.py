# Determina si un número es positivo y menor que 100

numero = float(input("Ingrese un número: "))

if numero > 0 and numero < 100:
    print("El número es positivo y menor que 100")
else:
    print("El número no cumple la condición")