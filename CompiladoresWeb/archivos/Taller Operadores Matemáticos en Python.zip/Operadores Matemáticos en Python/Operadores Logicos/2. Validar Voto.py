# Determina si una persona puede votar

edad = int(input("Ingrese su edad: "))

if edad >= 18 and edad < 100:
    print("La persona puede votar")
else:
    print("La persona no puede votar")