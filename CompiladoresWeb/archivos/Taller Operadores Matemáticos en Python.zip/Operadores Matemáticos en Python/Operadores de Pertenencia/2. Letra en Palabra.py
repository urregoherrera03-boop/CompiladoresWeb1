# Verifica si una letra pertenece a una palabra

palabra = "Python"

letra = input("Ingrese una letra: ")

if letra in palabra:
    print("La letra está dentro de la palabra")
else:
    print("La letra no está dentro de la palabra")