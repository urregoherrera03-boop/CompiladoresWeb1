# Usa not in para verificar que un número no esté en un rango

rango = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

numero = int(input("Ingrese un número: "))

if numero not in rango:
    print("El número no pertenece al rango")
else:
    print("El número pertenece al rango")