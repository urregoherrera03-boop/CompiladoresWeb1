# Verifica si un número ingresado está en una lista

numeros = [10, 20, 30, 40, 50]

numero = int(input("Ingrese un número: "))

if numero in numeros:
    print("El número está dentro de la lista")
else:
    print("El número no está dentro de la lista")