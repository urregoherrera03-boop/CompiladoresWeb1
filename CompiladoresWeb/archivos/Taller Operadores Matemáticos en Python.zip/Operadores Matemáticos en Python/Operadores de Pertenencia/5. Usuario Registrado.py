# Valida si un usuario existe en una lista de usuarios registrados

usuarios = ["ana", "juan", "carlos", "maria"]

usuario = input("Ingrese el nombre de usuario: ")

if usuario in usuarios:
    print("Usuario encontrado. Acceso permitido")
else:
    print("Usuario no registrado")