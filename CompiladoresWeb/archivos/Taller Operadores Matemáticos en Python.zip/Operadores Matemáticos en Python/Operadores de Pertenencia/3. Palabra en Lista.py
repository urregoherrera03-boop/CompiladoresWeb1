# Comprueba si una palabra está dentro de una lista

palabras = ["python", "java", "html", "css"]

palabra = input("Ingrese una palabra: ")

if palabra in palabras:
    print("La palabra está registrada en la lista")
else:
    print("La palabra no está en la lista")