# Conversión de dólares a pesos usando operador de asignación

dolares = float(input("Ingrese cantidad de dólares: "))
tasa = 4000  # Valor aproximado de conversión

pesos = dolares

pesos *= tasa

print("Valor en pesos colombianos:", pesos)