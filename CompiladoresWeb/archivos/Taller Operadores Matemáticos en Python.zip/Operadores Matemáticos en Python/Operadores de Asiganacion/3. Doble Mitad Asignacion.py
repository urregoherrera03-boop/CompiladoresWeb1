# Calcula doble y mitad usando operadores de asignación

numero = float(input("Ingrese un número: "))

doble = numero
doble *= 2

mitad = numero
mitad /= 2

print("Doble del número:", doble)
print("Mitad del número:", mitad)