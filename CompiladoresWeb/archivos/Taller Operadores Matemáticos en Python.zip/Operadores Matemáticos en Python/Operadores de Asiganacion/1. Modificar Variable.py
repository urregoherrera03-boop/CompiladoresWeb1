# Uso de operadores de asignación +=, -=, *=, /=

valor = 100

print("Valor inicial:", valor)

valor += 20
print("Después de += 20:", valor)

valor -= 10
print("Después de -= 10:", valor)

valor *= 2
print("Después de *= 2:", valor)

valor /= 5
print("Después de /= 5:", valor)