# Incrementa una variable en 3 unidades cinco veces

numero = 0

for i in range(5):
    numero += 3
    print("Incremento", i + 1, ":", numero)