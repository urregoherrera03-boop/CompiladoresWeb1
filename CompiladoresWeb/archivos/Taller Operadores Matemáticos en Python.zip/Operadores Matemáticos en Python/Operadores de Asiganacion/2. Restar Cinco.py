# Resta 5 usando operador de asignación

numero = float(input("Ingrese un número: "))

numero -= 5

print("Resultado después de restar 5:", numero)