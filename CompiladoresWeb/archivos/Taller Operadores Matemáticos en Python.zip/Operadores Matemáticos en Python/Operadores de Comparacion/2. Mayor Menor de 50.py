# Determina si un número es mayor o menor que 50

numero = float(input("Ingrese un número: "))

if numero > 50:
    print("El número es mayor que 50")
elif numero < 50:
    print("El número es menor que 50")
else:
    print("El número es igual a 50")