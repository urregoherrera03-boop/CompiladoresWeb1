# Determina si un número está entre 10 y 20

numero = float(input("Ingrese un número: "))

if numero >= 10 and numero <= 20:
    print("El número está entre 10 y 20")
else:
    print("El número no está dentro del rango")