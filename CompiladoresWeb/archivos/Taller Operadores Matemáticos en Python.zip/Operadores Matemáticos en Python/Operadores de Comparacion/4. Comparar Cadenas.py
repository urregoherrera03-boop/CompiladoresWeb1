# Compara si dos cadenas de texto son iguales

texto1 = input("Ingrese el primer texto: ")
texto2 = input("Ingrese el segundo texto: ")

if texto1 == texto2:
    print("Los textos son iguales")
else:
    print("Los textos son diferentes")