# Verifica si la suma de dos números es mayor que 100

numero1 = float(input("Ingrese el primer número: "))
numero2 = float(input("Ingrese el segundo número: "))

suma = numero1 + numero2

if suma > 100:
    print("La suma es mayor que 100")
else:
    print("La suma es menor que 100")